# v15.1 驗證紀錄

| 項目 | 方式 | 結果 |
| --- | --- | --- |
| 核心回歸 | `node tests/core.test.cjs` | PASS，41 項 |
| 舊功能整合 | `node tests/integration.test.cjs` | PASS，22 項。含 Excel 寫出重讀、華茂對帳、查詢翻頁後完整匯出、華茂與拍檔下單及實際華茂樣本。 |
| 案件與匯入 | `node --test tests/cases.test.cjs tests/imports.test.cjs` | PASS，22 項。含實際 POS 與 VK、拍檔請款、回填、SAP 欄位、跨頁勾選、錯檔拒絕及背景執行緒。 |
| 靜態與本機啟動 | `python3 tests/check_package.py` 及 `python3 tests/http.test.py` | PASS，五個主要工作區直接顯示，12 個首頁上傳欄位皆有正確檔型，12 個執行資源均回傳 HTTP 200。 |
| 瀏覽器與 Windows | Chromium 啟動及實際使用環境 | BLOCKED，執行環境拒絕 Chromium 啟動所需的 socket。瀏覽器渲染、實際 FPS、長任務、Windows 剪貼簿和下載未驗證。 |

真實樣本透過 `POS_FIXTURE`、`VK_FIXTURE`、`HM_FIXTURE`、`SALES_FIXTURE` 環境變數提供。ZIP 隨附合成測試素材，原始營運文件由各自的受控位置取用。

## 效能對照

Node.js v24.22.1，兩版使用同一份合成工作檔（15,000 案、7,500 張發票）。暖機後取 3–5 次中位數。模擬 DOM 只記錄更新次數與 JavaScript 處理時間，瀏覽器排版及畫面更新另需驗證。重現方式為 `node tests/performance.cjs /path/to/v15.0/site`。

| 操作 | v15.0 | v15.1 |
| --- | ---: | ---: |
| 篩選「待核對」 | 1663.65 ms | 2.48 ms |
| 同頁勾選或取消共 30 次 | 144.12 ms／重建 30 次 | 0.07 ms／重建 0 次 |
| 同一幀連續 6 次搜尋輸入 | 174.76 ms／重建 6 次 | 3.39 ms／重建 1 次 |
| 短時間收到 3,000 筆紀錄 | 109.87 ms／更新 3,000 次 | 1.55 ms／更新 1 次 |

在 Windows 與正式網域驗收時，可依次測試瀏覽器載入大型 POS、搜尋、勾選、跨頁補匯入、PDF 首次載入、LINE／Email 複製及 Excel 下載。瀏覽器開發工具的 Performance 面板可用於比對兩版的 FPS 與長任務。
